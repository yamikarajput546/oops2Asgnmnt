package pvn

trait Ordered {
  def person(): Unit;

}
