package pvn

object main {
  def main(args: Array[String]): Unit = {

    val object1 = new Person(24, "testAgain")
    val object2 = new Person(25, "test")


    if ((object1.Name).equals(object2.Name)) { // if name equals

      if ((object1.Age) <= (object2.Age)) {
        println("true")
      }
      else{
        println("false")
      }


    }

    else {
      if ((object1.Name.length()) < ((object2.Name.length()))) { // compare the length
        println("true")
      }
      else {
        println("false")
      }


    }

  }
}