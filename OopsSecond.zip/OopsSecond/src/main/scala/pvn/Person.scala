package pvn


case class Person(Age: Int,Name: String)
{


}